AI WORKFLOW AUTOMATION SHOW-AND-TELL: HANDOFF PACKAGE

CURRENT MASTER: AI_Workflow_Show_and_Tell_Refined.pptx
NOTES PDF: AI_Workflow_Show_and_Tell_Refined_with_notes.pdf
FULL PROJECT CONTEXT: AI_Workflow_Show_and_Tell_HANDOFF.md
REFINEMENT SCRIPT: refine_deck.py
ORIGINAL PRESENTATION: AI_Workflow_Show_and_Tell.pptx

Slides 9-11 remain demonstration placeholders.
The provided refine_deck.py patches the original PowerPoint; it is NOT the original
build_deck.py generator. The generator and icons.js were shared in the chat as text.
