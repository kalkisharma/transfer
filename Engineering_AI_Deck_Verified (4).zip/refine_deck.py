"""Professional content pass on the supplied 12-slide editable deck.

Run: python /mnt/data/refine_deck.py
Uses the original PowerPoint as the master, preserving vector objects, embedded icons,
slide order, notes and 16:9 layout. Changes are copy, a small definition on slide 2,
and refreshed presenter notes. No program-specific content is fabricated.
"""
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.text import MSO_ANCHOR

ROOT = Path('/mnt/data')
SRC = ROOT / 'AI_Workflow_Show_and_Tell.pptx'
DST = ROOT / 'AI_Workflow_Show_and_Tell_Refined.pptx'
prs = Presentation(SRC)

# Every replacement is checked for exactly one matching textbox to avoid silently editing
# the wrong label when the supplied master is revised.
def replace(slide_no, old, new, size=None):
    slide = prs.slides[slide_no-1]
    matches = [sh for sh in slide.shapes if sh.has_text_frame and sh.text == old]
    if len(matches) != 1:
        raise ValueError((slide_no, old, len(matches)))
    sh = matches[0]
    para = sh.text_frame.paragraphs[0]
    if len(sh.text_frame.paragraphs) != 1:
        raise ValueError('paragraph shape: ' + old)
    if not para.runs:
        raise ValueError('no runs: ' + old)
    para.runs[0].text = new
    for r in para.runs[1:]: r.text = ''
    if size is not None:
        para.runs[0].font.size = Pt(size)
    return sh


def replace_bullets(slide_no, old_lines, new_lines):
    slide = prs.slides[slide_no-1]
    matches = [sh for sh in slide.shapes if sh.has_text_frame and [p.text for p in sh.text_frame.paragraphs] == old_lines]
    if len(matches) != 1:
        raise ValueError((slide_no, 'bullets', len(matches)))
    sh = matches[0]
    for p, val in zip(sh.text_frame.paragraphs, new_lines):
        p.runs[0].text=val
        for rr in p.runs[1:]: rr.text=''
    return sh

# 1 — Broad engineering framing, without retitling the speaker's actual specialty.
replace(1, 'MONTHLY SHOW-AND-TELL  ·  AEROSCIENCES', 'MONTHLY SHOW-AND-TELL  ·  ENGINEERING')

# 2 — Explicit on-ramp for people who haven't used an agent.
replace(2, 'Agents and coding assistants are already on our desks',
           'AI assistants can help with repetitive tasks')
replace(2, 'No easy on-ramp yet', 'Where do you start?')
replace(2, "Hard to know where to start, or what's worth trying",
           'A small, practical example makes it easier')
replace(2, 'You present here soon', 'You could present next')
replace(2, 'Show one workflow, any size, from any discipline',
           'Share one useful workflow, from any team')
slide = prs.slides[1]
tb = slide.shapes.add_textbox(Inches(.7), Inches(1.30), Inches(11.9), Inches(.42))
tb.name = 'Agent plain-language definition'
tf=tb.text_frame
for side in ('margin_left','margin_right','margin_top','margin_bottom'): setattr(tf,side,0)
tf.word_wrap = True
p = tf.paragraphs[0]
r=p.add_run(); r.text = 'An agent is an AI assistant that can work through steps using the files and tools it can access.'
r.font.name='Calibri'; r.font.size=Pt(17); r.font.color.rgb=RGBColor.from_string('5A6684')

# 3 — Demonstration no longer requires an aero-specific plot; avoid implying guaranteed outcomes.
replace(3, 'An agent is only as good as the context you give it',
           'Good context reduces guesswork')
replace(3, '“Make me a lift plot.”', '“Make me a plot.”')
replace(3, 'Guessed columns, wrong units, generic style',
           'Needs guesses about data, units, and format', size=16)
replace(3, '“Plot CL vs. α from run_042.csv, α in degrees, styled like fig3.png.”',
           '“Plot force vs. time from test_042.csv (s, N). Match example.png.”')
replace(3, 'Right data, right units, ready to use',
           'Specific inputs and format—still verify', size=16)

# 4 — Four *possible* context sources (not four mandatory parts of every prompt).
replace(4, 'Four kinds of context', 'Four sources of context')
replace(4, 'Most good workflows use all four',
           'Give the agent the context it needs for this task')
replace(4, 'Header prompt', 'Task request')
replace(4, 'Who you are, the task, and what “done” looks like',
           'The task, constraints, and what success looks like')
replace(4, 'AGENTS.md: standing instructions it reads every time',
           'AGENTS.md or other reusable project instructions')
replace(4, 'Manuals, specs, past reports, good examples',
           'Specifications, guidance, and approved examples')
replace(4, 'Your own data', 'Working files')
replace(4, 'Run outputs, test data, input decks',
           'Measurements, inputs, results, and models')
s4bar = [sh for sh in prs.slides[3].shapes if sh.has_text_frame and 'sees only what you give it' in sh.text]
assert len(s4bar) == 1
runs = s4bar[0].text_frame.paragraphs[0].runs
assert len(runs) == 2
runs[1].text = '   uses the context and tools it can access'

# 5 — General engineering sequence: sequential steps, checks between handoffs.
replace(5, 'One step at a time, with a check between every step',
           'Build a repeatable chain, with checks at each handoff')
for old,new in [
    ('Report','Test report'), ('Tables','Extract data'),
    ('Input deck','Prepare inputs'), ('Run','Run analysis'),
    ('HTML report','Summary')]:
    replace(5,old,new, size=16 if len(new)>11 else None)
s5bar = [sh for sh in prs.slides[4].shapes if sh.has_text_frame and sh.text.startswith('A check can be a script')]
assert len(s5bar) == 1
runs=s5bar[0].text_frame.paragraphs[0].runs
assert len(runs)==2
runs[0].text = 'A check can be a script, a test, or you.  '
runs[1].text = 'If it fails, fix it before moving on.'

# 6 — Make the role of the coordinator and the difference from chaining explicit.
replace(6, 'Specialized agents, each feeding one combined result',
           'A coordinator assigns focused jobs, then combines the results')
replace(6, 'Which CFD runs finished or failed', 'Which analyses passed or failed')
replace(6, 'New tunnel points vs. CFD', 'New measurements vs. model')
replace(6, 'Open items from meeting notes', 'Open actions from meeting notes')
replace(6, 'Milestones coming up', 'Upcoming reviews and deadlines')

# 7 — Advice that is applicable, actionable, and appropriately qualified.
replace(7, 'Three practical rules', 'Three practical habits')
replace(7, 'Examples beat rule lists', 'Show a good example')
replace(7, 'One good output teaches more than ten rules',
           'A trusted sample makes success concrete')
replace(7, '“Match last month\'s report.”', '“Use the approved report format.”')
replace(7, "Point to files, don't paste", 'Reference the right files')
replace(7, 'Let the agent read what it needs, when it needs it',
           'Give it access to the relevant source material')
replace(7, '“Read docs/bc_setup.md first.”', '“Read docs/test_plan.md first.”')
replace(7, 'Start with one simple chain', 'Start with one small chain')
replace(7, "Two steps that work beat ten that don't", 'Get two steps working, then add more')
replace(7, 'Report → table. Done. Then add one.',
           'Report → table → check.')

# 8 — Change verification from a vague analogy to concrete engineering checks.
replace(8, "Verify agent work the way you'd verify a teammate's",
           'Speed is useful; verification is still an engineering responsibility')
replace(8, 'Treat it like a sharp new hire: fast, eager, and sometimes confidently wrong.',
           "Fast and capable doesn't mean verified. You still own the engineering judgment.")
replace(8, 'Read what it did, not just the final answer',
           'Check assumptions, units, and sources')
replace(8, 'Re-derive a few numbers by hand',
           'Recalculate at least one critical result')
replace(8, 'Test data, a validated run, or a known case',
           'Use test data, a baseline, or a known case')

# 9–11 — Improve demonstrator's narrative without guessing cleared program content.
replace(9, 'Demo 1: Setup hub with embedded chatbot', 'Demo 1: Getting started')
replace(9, '[Placeholder] Add program-specific content here',
           'Setup hub + embedded chatbot')
replace(9, 'Drop in: screenshot, short clip, or live demo',
           'Show the entry point')
replace(9, 'Ideas to cover:', 'Audience takeaway:')
replace_bullets(9,
  ['What the hub sets up for a new user', 'Ask the embedded chatbot a real question, live',
   'Where people can find it after today'],
  ['Where to find the hub and what it sets up',
   'Ask a real setup question and inspect the answer',
   'One step everyone can try after this session'])

replace(10, 'Demo 2: Program workflow example', 'Demo 2: An engineering workflow')
replace(10, '[Placeholder] Add program-specific content here',
           'Before → automated steps → reviewed result')
replace(10, 'Drop in: screenshot, short clip, or live demo',
           'Show the before and after')
replace(10, 'Ideas to cover:', 'Audience takeaway:')
replace_bullets(10,
  ['The problem it solves: before vs. after',
   'The chain or agents behind it (tie back to patterns 1 and 2)',
   'Time saved, and what still needs a human'],
  ['What was tedious or error-prone before?',
   'Which steps are automated—and which are checked?',
   'What improved? Time, consistency, or fewer handoffs?'])

replace(11, 'Demo 3: RCAS live run', 'Demo 3: RCAS end to end')
replace(11, '[Placeholder] Add program-specific content here',
           'Input → checks → reviewed output')
replace(11, 'Drop in: screenshot, short clip, or live demo',
           'Walk through a real run')
replace(11, 'Ideas to cover:', 'Audience takeaway:')
replace_bullets(11,
  ['Input deck → run → report, live', 'Where the checks catch mistakes',
   'Backup: recorded run in case live fails'],
  ['Show the inputs and what the workflow produces',
   'Highlight one concrete verification gate',
   'Use a recorded example if the live run is unavailable'])

# 12 — Finish with an invitation and achievable action.
replace(12, 'Low barrier. Have fun.', 'Start small. Have fun.')
replace(12, 'Small, scrappy workflows are perfect',
           'Even a ten-minute improvement counts')
replace(12, 'You present next', 'Share your workflow next')
replace(12, 'Ten minutes, one workflow, any discipline',
           'Ten minutes, one example, any team')
replace(12, 'My door\'s open', 'Want a hand?')
replace(12, 'Bring a charge number for hands-on help',
           'Bring a charge number for hands-on help')
replace(12, 'Git', 'Git basics')

speaker_notes={
1: "Welcome to our monthly, informal show-and-tell on AI-assisted engineering workflows. No AI expertise is assumed. Whether your work involves design, test, analysis, software, or project coordination, you probably have a repetitive task worth exploring. We'll cover a few concepts, see practical examples, and keep the emphasis on workflows you could try yourself.",
2: "The goal isn't to turn everyone into an AI developer. An agent is simply an AI assistant that can use permitted tools and files to work through steps. The tools can be useful, but the starting point isn't always obvious. This series gives us a place to swap small, practical examples. Eventually, I'd love to see people from different engineering teams share what worked, including the mistakes and lessons.",
3: "Consider the same plotting request. 'Make me a plot' leaves the data source, quantities, units, and output style ambiguous. A more specific request names the file, units, and a reference figure. That reduces guesswork, but does not guarantee a correct plot. We still need to examine the inputs and check the result. Context improves the odds of getting something useful on the first pass.",
4: "Think of four sources of context. First, the current task and definition of success. Second, reusable project instructions, such as AGENTS.md if the tool supports them. Third, reference material: manuals, specifications, and examples. Fourth, the working files and data. You don't always need all four. The important point is that the agent can only use material and tools it is actually authorized and able to access.",
5: "The first pattern is a chain: one step produces something the next step needs. For example, read a test report, extract values, prepare model inputs, run an analysis, and summarize the results. Put a check at each handoff: missing values, wrong units, invalid inputs, failed jobs, or implausible outputs. A check can be code or a human. Don't automate a long chain until the small pieces behave reliably.",
6: "The second pattern works when jobs can be split. A coordinator asks different workers for run status, measurements, action items, and milestones, then combines their findings in a weekly report. A worker might be a separate agent, script, or tool call. Unlike a chain, these tasks need not depend on one another. This is useful for larger workflows, but it's not the place to start if one simple chain will do.",
7: "Three habits that help. Show a good example of the output you want, while still supplying any important requirements. Give the assistant access to the specific files it needs rather than copying everything into a giant prompt; follow the data-handling rules for your tools. Finally, start with two reliable steps before growing the workflow. The aim is a repeatable process, not the most elaborate collection of agents.",
8: "This is the engineering question: how do we know the output is right? Review the method and inspect assumptions, units, and sources. Recalculate a meaningful result independently. Compare it with test data, an approved baseline, or a known case. Keep normal quality, technical review, and data-control processes in place. AI can accelerate parts of the work; responsibility for the engineering conclusion remains with us.",
9: "[DEMO CONTENT PENDING] Start with the setup hub. Show exactly where a new user finds it, what setup it handles, and one common question you can ask the embedded chatbot. Inspect the answer rather than simply accepting it. End with a one-step challenge the audience can try after this meeting. Replace the placeholder with a cleared screenshot or live view before presenting.",
10: "[DEMO CONTENT PENDING] Choose a program-cleared example with a recognizably tedious before state. Briefly show the inputs, the automated steps, the verification checkpoint, and the reviewed result. Tie it back to chaining or coordinator-worker patterns without overexplaining implementation. Quantify time saved only if you've measured it. Confirm every screenshot, file name, and result is approved for this audience.",
11: "[DEMO CONTENT PENDING] For RCAS, show one cleared input, the sequence of tasks, a real validation point, and the final artifact. Mention how a failed check is handled rather than presenting only a perfect run. A short recording can replace the live portion if access, runtime, or connectivity is uncertain. Keep sensitive program data out of the slide and screen-share unless approved.",
12: "You are the expert in your own work; the agent is a tool you direct and check. Start with one small repetitive task and see whether it helps. A short, imperfect demonstration is welcome next month; the purpose is to learn from each other. If you'd like hands-on help, reach out with a charge number. Future sessions can explore token efficiency, model selection, and Git basics. Questions?"
}
for i,nt in speaker_notes.items():
    prs.slides[i-1].notes_slide.notes_text_frame.text = nt

# Mechanical content assertions.
assert len(prs.slides)==12
assert abs(prs.slide_width/Inches(1)-13.333)<.01
for i,s in enumerate(prs.slides,1):
    joined=' '.join(sh.text for sh in s.shapes if sh.has_text_frame)
    assert 'AEROSCIENCES' not in joined.upper()
    assert 'aerospace sciences' not in s.notes_slide.notes_text_frame.text.lower()
    assert s.notes_slide.notes_text_frame.text.strip()
prs.save(DST)
print(DST)
