# Sources — Viking LR legacy-data extraction demo

All sources are public NASA / NASA-funded. Retrieved 2026-11-12.

## Digital archive (ground truth for validation)

1. **NSSDCA catalog entry, PSBI-00001** — Viking Lander Labeled Release Experiment Archive (PDS).
   https://nssdc.gsfc.nasa.gov/nmc/dataset/display.action?id=PSBI-00001
2. **PDS Geosciences Node, Viking Lander LR landing page** (PDS4 bundle + PDS3 volume VL_9010).
   https://pds-geosciences.wustl.edu/missions/vlander/lr.html
3. **Data set catalog (PDS3), VL1/VL2-M-LR-2-EDR-V1.0** — data sources (Straat computer listings + NSSDC microfilm), hand transcription, 0.25% keying-error estimate, units, time system.
   https://pds-geosciences.wustl.edu/viking/vl1_vl2-m-lr-2-edr-v1/vl_9010/catalog/dataset.cat
4. **Errata** — anomaly ('A') and mode-switch ('M') flags; corrections to VL1C3HT and VL2C1DT.
   https://pds-geosciences.wustl.edu/viking/vl1_vl2-m-lr-2-edr-v1/vl_9010/errata.txt
5. **Column definitions** (label for VL1C1RC.TAB).
   https://pds-geosciences.wustl.edu/viking/vl1_vl2-m-lr-2-edr-v1/vl_9010/data/vl1c1rc.lbl
6. **Data files used** (PDS4 bundle `urn:nasa:pds:vl_labeled_release`, collection `data_raw`):

| File | Rows | Bytes | SHA-256 |
|---|---|---|---|
| [viking_lander_1/vl1c1rc.tab](https://pds-geosciences.wustl.edu/viking/urn-nasa-pds-vl_labeled_release/data_raw/viking_lander_1/vl1c1rc.tab) | 1455 | 173,145 | `cdaaa50843b248326fdb64a1131cbabf5e7934b283fccb4af4032952058efece` |
| [viking_lander_2/vl2c1rc.tab](https://pds-geosciences.wustl.edu/viking/urn-nasa-pds-vl_labeled_release/data_raw/viking_lander_2/vl2c1rc.tab) | 1538 | 183,022 | `ce42edac4c6b0883521745e7ba522f4fccedc039bc2e3afb3f6fe414ec820c90` |
| [viking_lander_1/vl1c4rc.tab](https://pds-geosciences.wustl.edu/viking/urn-nasa-pds-vl_labeled_release/data_raw/viking_lander_1/vl1c4rc.tab) | 1833 | 218,127 | `fa3198a38c0f21ca0fbcf54923802f320c84660284ef274c698177ce73feaf26` |
| [viking_lander_2/vl2c5rc.tab](https://pds-geosciences.wustl.edu/viking/urn-nasa-pds-vl_labeled_release/data_raw/viking_lander_2/vl2c5rc.tab) | 3225 | 351,525 | `6ee2ca117ea73f7969042388dd4f0f2df9132550d9ab7e29909f6ec34e2b0acc` |

   `pds_lr_archive_records_used.txt` holds the verbatim records within ±0.3 h of each table time, plus a decimated series used only for the plot.

   Dataset citation: Levin, G.V., VL1/VL2 Mars Labeled Release V1.0, VL1/VL2-M-LR-2-EDR-V1.0, NASA Planetary Data System, 2001.

## Scanned source (extraction target)

7. **Levin, G. V. (1979). *Analysis and interpretation of Viking labeled release experimental results.* Final Report, NASA-CR-162149 (contract NASW-3162), Biospherics Inc., June 19, 1979.**
   - Record: https://ntrs.nasa.gov/citations/19790022948
   - PDF: https://ntrs.nasa.gov/api/citations/19790022948/downloads/19790022948.pdf (120 pages, 300-dpi CCITT G4 scans)
   - **Page used: PDF page 33 = printed page 23, Table I, "Percent Inhibition from Stored Samples"** (printed sideways).
   - Other flight-data pages in the same report (figures, not tables): Fig. 5 (PDF p. 30), Fig. 6 (p. 31), Fig. 7 (p. 32), Fig. 8 (p. 37), Fig. 9 (p. 38).

## Background (not used for numbers)

8. Levin & Straat (1977), "Recent results from the Viking Labeled Release experiment on Mars," JGR 82 — NTRS record (no download): https://ntrs.nasa.gov/citations/19780027540
9. Development of biological and nonbiological explanations for the Viking label release data, NASA-CR-163291 (1980): https://ntrs.nasa.gov/citations/19800018756
