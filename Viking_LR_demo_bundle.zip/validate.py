"""Stage 3: validate Table I extraction (NASA-CR-162149 p.23) against PDS LR archive records.

Inputs
  out/table1_extracted.csv     - values transcribed from the scanned page
  raw/archive_extract.txt      - verbatim PDS records (windows of +/-0.3 h around each
                                 table time) + a decimated series for plotting
Outputs
  out/validation_results.csv
  out/lr_extracted_vs_archive.png
"""
import csv, math, re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

W = "/home/claude/work/"

# ---------- parse archive extract ----------
windows, series = {}, {}
section, key = None, None
for line in open(W + "raw/archive_extract.txt"):
    line = line.rstrip("\n")
    if line.startswith("# windows"): section = "w"; continue
    if line.startswith("# series"): section = "s"; continue
    m = re.match(r"## (\w+)(?: target_h=([\d.]+))?", line)
    if m:
        key = (m.group(1), float(m.group(2))) if section == "w" else m.group(1)
        (windows if section == "w" else series)[key] = []
        continue
    if not line.strip():
        continue
    f = [x.strip().strip('"') for x in line.split(",")]
    if section == "w":
        vl25 = key[0] == "VL2C5"  # VL2C5 has one injection -> no 2nd-injection column
        windows[key].append(dict(
            raw=float(f[0]), bgc=float(f[1]), channel=int(f[2]), mmt=int(f[3]),
            native=f[4].strip(), utc=f[5], h1=float(f[6]),
            h2=None if vl25 else float(f[7]),
            counting_s=int(f[8] if vl25 else f[9]), note=f[-1].strip(), line=line))
    else:
        series[key].append((float(f[0]), float(f[1])))

# ---------- extracted rows ----------
rows = list(csv.DictReader(open(W + "out/table1_extracted.csv")))

def sol_of(native):  # "232/06:01:13" or " 10/07:58:20"
    return int(native.split("/")[0])

out = []
for r in rows:
    sid, h, cpm = r["sample_id"], float(r["hours_from_1st_injection"]), int(r["cpm"])
    cands = windows[(sid, h)]
    near = min(cands, key=lambda c: abs(c["h1"] - h))                 # strategy A
    best = min(cands, key=lambda c: (abs(round(c["bgc"]) - cpm), abs(c["h1"] - h)))  # strategy B
    exp_inj = int(r["n_injections_in_test_cell"])
    arch_inj = 1 if (best["h2"] is None or best["h2"] < 0) else 2
    diff = cpm - round(best["bgc"])
    out.append(dict(
        row_id=r["row_id"], sample_id=sid, table_hours=h, extracted_cpm=cpm,
        A_nearest_time_h=near["h1"], A_archive_bgc_cpm=near["bgc"],
        A_match=round(near["bgc"]) == cpm,
        B_matched_h=best["h1"], B_dt_h=round(best["h1"] - h, 3),
        B_archive_bgc_cpm=best["bgc"], B_archive_raw_cpm=best["raw"],
        B_diff_cpm=diff, B_pct_diff=round(100 * diff / best["bgc"], 3),
        B_match=diff == 0, n_candidates_in_window=len(cands),
        archive_mmt_s=best["mmt"], archive_native_time=best["native"],
        archive_sol=sol_of(best["native"]), archive_utc=best["utc"],
        archive_counting_interval_s=best["counting_s"], archive_note=best["note"],
        injections_consistent=exp_inj == arch_inj,
    ))

# ---------- internal consistency: recompute % inhibition from extracted CPM ----------
by = {(r["sample_id"], float(r["hours_from_1st_injection"])): r for r in rows}
inhib = []
for h, stored in [(2.37, "VL1C4"), (200, "VL1C4"), (1.86, "VL2C5"), (90, "VL2C5")]:
    s = int(by[(stored, h)]["cpm"])
    lo_hi = sorted(100 * (1 - s / int(by[(a, h)]["cpm"])) for a in ("VL1C1", "VL2C1"))
    col = "pct_inhibition_vs_VL1_cycle4" if stored == "VL1C4" else "pct_inhibition_vs_VL2_cycle5"
    printed = by[(stored, h)][col]
    p = [int(x) for x in re.findall(r"\d+", printed)]
    ok = round(lo_hi[0]) == p[0] and round(lo_hi[1]) == p[1]
    inhib.append((stored, h, round(lo_hi[0], 1), round(lo_hi[1], 1), printed, ok))

with open(W + "out/validation_results.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
    w.writeheader(); w.writerows(out)

nA = sum(o["A_match"] for o in out); nB = sum(o["B_match"] for o in out)
print(f"Strategy A (nearest time to printed hour): {nA}/12")
print(f"Strategy B (best value within +/-0.3 h):   {nB}/12")
for o in out:
    if not (o["A_match"] and o["B_match"]):
        print(o["row_id"], o["sample_id"], o["table_hours"], o["extracted_cpm"],
              "| A:", o["A_nearest_time_h"], o["A_archive_bgc_cpm"],
              "| B:", o["B_matched_h"], o["B_archive_bgc_cpm"], "diff", o["B_diff_cpm"],
              "cands", o["n_candidates_in_window"])
print("injection-count consistent:", all(o["injections_consistent"] for o in out))
print("abs |dt| strategy B:", sorted({o['B_dt_h'] for o in out}))
for i in inhib: print("inhibition", i)
for o in out: print(o["sample_id"], o["table_hours"], "sol", o["archive_sol"], o["archive_native_time"], o["archive_utc"])

# ---------- plot ----------
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
COL = {"VL1C1": "#2a78d6", "VL2C1": "#eb6834", "VL1C4": "#1baf7a", "VL2C5": "#eda100"}
NAME = {"VL1C1": "VL-1 Cycle 1 (active)", "VL2C1": "VL-2 Cycle 1 (active)",
        "VL1C4": "VL-1 Cycle 4 (stored sample)", "VL2C5": "VL-2 Cycle 5 (stored sample)"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10.5,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2})
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 6.0), gridspec_kw={"width_ratios": [1, 1.55]})
fig.patch.set_facecolor(SURF)
for ax in (ax1, ax2):
    ax.set_facecolor(SURF)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    ax.grid(True, color=GRID, lw=0.8); ax.set_axisbelow(True)

# parity (log-log; values span 234-12,522 cpm)
x = [o["B_archive_bgc_cpm"] for o in out]; y = [o["extracted_cpm"] for o in out]
ax1.plot([150, 20000], [150, 20000], color=INK2, lw=1, ls="--", zorder=1)
for o in out:
    ax1.scatter(o["B_archive_bgc_cpm"], o["extracted_cpm"], s=64, color=COL[o["sample_id"]],
                edgecolor=SURF, linewidth=2, zorder=3)
ax1.set_xscale("log"); ax1.set_yscale("log")
ax1.set_xlim(150, 20000); ax1.set_ylim(150, 20000)
ax1.set_xlabel("PDS archive, background-corrected (cpm)")
ax1.set_ylabel("Extracted from 1979 scan (cpm)")
ax1.text(0.03, 0.97, "colors = cycle (legend at right)", transform=ax1.transAxes, fontsize=8.5, color=INK2, va="top")
ax1.set_title("Parity: 12 extracted values vs. archive", loc="left", color=INK, fontsize=12)
miss = [o for o in out if not o["B_match"]][0]
ax1.annotate(f"VL-2 C5 @ 90 h\nscan {miss['extracted_cpm']} vs archive {miss['B_archive_bgc_cpm']:.2f}",
             (miss["B_archive_bgc_cpm"], miss["extracted_cpm"]), xytext=(190, 1500),
             fontsize=9, color=INK2, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8))
ax1.text(0.97, 0.05, f"11 of 12 exact\n1 differs by 1 cpm (0.3%)", transform=ax1.transAxes,
         ha="right", va="bottom", fontsize=10.5, color=INK, fontweight="bold")
fmt = matplotlib.ticker.FuncFormatter(lambda v, p: f"{int(v):,}")
for a in (ax1.xaxis, ax1.yaxis):
    a.set_major_formatter(fmt); a.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax1.set_xticks([200, 500, 1000, 2000, 5000, 10000]); ax1.set_yticks([200, 500, 1000, 2000, 5000, 10000])

# time series
# Archive-flagged anomaly ('A' note) falling on the decimated series: VL1C4 h=35.23,
# raw 10.42 cpm / bgc -719.58 (checked against the full vl1c4rc.tab record). Drawn as a gap.
FLAGGED = {("VL1C4", 35.23)}
for sid in ["VL1C1", "VL2C1", "VL1C4", "VL2C5"]:
    hs = [h for h, v in series[sid]]
    vs = [float("nan") if (sid, h) in FLAGGED else v for h, v in series[sid]]
    ax2.plot(hs, vs, color=COL[sid], lw=2, label=NAME[sid], zorder=2)
for o in out:
    ax2.scatter(o["B_matched_h"], o["extracted_cpm"], s=80, marker="D", facecolor=SURF,
                edgecolor=INK, linewidth=1.6, zorder=4)
ax2.scatter([], [], s=60, marker="D", facecolor=SURF, edgecolor=INK, linewidth=1.6,
            label="Value read from 1979 scan")
ax2.set_xlim(-5, 225); ax2.set_ylim(-500, 14500)
ax2.set_xlabel("Hours from first nutrient injection")
ax2.set_ylabel("Radioactivity, background-corrected (cpm)")
ax2.set_title("Archive time series with extracted points overlaid", loc="left", color=INK, fontsize=12)
ax2.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, p: f"{int(v):,}"))
ax2.legend(frameon=False, fontsize=9.5, loc="upper center", bbox_to_anchor=(0.5, -0.13), ncol=3, labelcolor=INK)
ax2.annotate("archive-flagged anomaly ('A'),\nh 35.2, not drawn", (35.2, 700), xytext=(22, 2700),
             fontsize=8.5, color=INK2, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8))
fig.text(0.01, 0.005, "Sources: PDS Geosciences Node VL1/VL2-M-LR-2-EDR-V1.0 (vl1c1rc, vl2c1rc, vl1c4rc, vl2c5rc); "
         "Levin 1979, NASA-CR-162149, Table I (printed p. 23). Archive series decimated to every 8th record for display.",
         fontsize=8, color=INK2)
fig.tight_layout(rect=(0, 0.035, 1, 1))
fig.savefig(W + "out/lr_extracted_vs_archive.png", dpi=200, facecolor=SURF)
